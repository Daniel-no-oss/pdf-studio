"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  FileEdit,
  Printer,
  Combine,
  Scissors,
  Home,
  Shield,
  Menu,
  X,
  LogOut,
  User as UserIcon,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { usePdfStore } from "@/store/pdf-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Image from "next/image";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const navItems = [
  { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
  { id: "editor", label: "Éditeur PDF", icon: FileEdit },
  { id: "print", label: "Préparer l'impression", icon: Printer },
  { id: "merge", label: "Fusionner", icon: Combine },
  { id: "split", label: "Découper", icon: Scissors },
] as const;

export function AppSidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const view = usePdfStore((s) => s.view);
  const setView = usePdfStore((s) => s.setView);
  const docs = usePdfStore((s) => s.docs);
  const user = usePdfStore((s) => s.user);
  const logout = usePdfStore((s) => s.logout);

  const onNav = (id: (typeof navItems)[number]["id"]) => {
    setView(id);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile top bar */}
      <div className="md:hidden sticky top-0 z-40 flex items-center justify-between border-b bg-background px-4 py-3 no-print">
        <button
          onClick={() => setView("dashboard")}
          className="flex items-center gap-2 font-bold text-primary"
        >
          <Image
            src="/logo.png"
            alt="PDF Studio"
            width={28}
            height={28}
            className="rounded"
            priority
          />
          <span>PDF Studio</span>
        </button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 z-40 bg-black/40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={cn(
          "no-print z-50 flex w-64 shrink-0 flex-col border-r bg-sidebar text-sidebar-foreground",
          "fixed inset-y-0 left-0 top-[57px] md:top-0 transition-transform md:static md:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <div className="hidden md:flex items-center gap-2.5 px-5 py-5 border-b">
          <Image
            src="/logo.png"
            alt="PDF Studio"
            width={36}
            height={36}
            className="rounded-lg shadow-sm"
            priority
          />
          <div className="leading-tight">
            <div className="font-bold text-base text-foreground">PDF Studio</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
              Mise en page & impression
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto thin-scroll">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNav(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                    : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground text-sidebar-foreground/80"
                )}
              >
                <Icon className="h-4.5 w-4.5 shrink-0" />
                <span className="truncate">{item.label}</span>
                {item.id === "editor" && docs.length > 0 && (
                  <Badge variant="secondary" className="ml-auto text-[10px]">
                    {docs.length}
                  </Badge>
                )}
              </button>
            );
          })}
        </nav>

        {/* User profile + logout */}
        {user && (
          <div className="border-t p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center gap-2.5 rounded-lg p-2 hover:bg-sidebar-accent transition-colors">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/15 text-primary font-semibold text-sm">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1 text-left">
                    <div className="text-sm font-medium truncate">{user.name}</div>
                    <div className="text-[10px] text-muted-foreground truncate">
                      {user.email}
                    </div>
                  </div>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex items-center gap-2">
                    <UserIcon className="h-4 w-4" />
                    <span className="truncate">{user.name}</span>
                  </div>
                  <div className="text-[10px] text-muted-foreground truncate mt-0.5">
                    {user.email}
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setView("dashboard")}>
                  <Home className="h-4 w-4 mr-2" />
                  Tableau de bord
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={logout}
                  className="text-destructive focus:text-destructive"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Déconnexion
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}

        <div className="border-t p-4 space-y-3">
          <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 dark:bg-emerald-950/30 dark:border-emerald-900">
            <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 text-xs font-semibold mb-1">
              <Shield className="h-3.5 w-3.5" />
              Confidentialité
            </div>
            <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-snug">
              Vos fichiers restent sur votre appareil. Aucun envoi vers un serveur.
            </p>
          </div>
          <div className="flex items-center justify-between text-[11px] text-muted-foreground">
            <span>v1.1</span>
            <span>FR</span>
          </div>
        </div>
      </aside>
    </>
  );
}
